var electron=require('electron')

var app=electron.app//引用app

var BrowserWindow=electron.BrowserWindow//窗口引用

var mainWindow=null;//声明要打开的主窗口

app.on('ready',()=>{
    mainWindow=new BrowserWindow({width:400,height:38,frame:false,resizable: false})
    mainWindow.loadFile('UI/run_main/index.html')//加载主html页面
    mainWindow.on('closed',()=>{
        mainWindow=null;
    })
})