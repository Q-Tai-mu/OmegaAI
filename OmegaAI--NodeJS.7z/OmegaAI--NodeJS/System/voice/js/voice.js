function openVoice(data){

    var VoiceInterface=' <audio autoplay="autoplay">\n' +
    '\t\t\t<source \n' +
    '\t\t\t\tsrc="https://nls-gateway.cn-shanghai.aliyuncs.com/stream/v1/tts?appkey=0AJEtyC66dKQiY9a&token=9b34a9d538934919bc3bfdea14f66347&format=mp3&voice=Aimei&speech_rate=-200&volume=80&text=\n' +
    '                '+data+'，\n' +
    '                "\n' +
    '\t\t\t\ttype="audio/mp3" />\n' +
    '\t\t</audio>';
    $("#space").html(VoiceInterface);
}

//读取JSON
function openJSON(JSON){
    $.getJSON(JSON, function (data){

    });
}