//与服务器通信交互数据
function openTCP(VAR){
    $.post("",{VARS:VAR},function(){

    });
}